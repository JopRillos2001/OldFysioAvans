const sql = require("mssql");

const config = {
    server: 'localhost\\SQLEXPRESS',
    port: 1433,
    user: "",
    password: "",
    database: "FysioStamDB",
    options: {
        enableArithAbort: true,
    },
    connectionTimeout: 150000,
    pool: {
        max: 10,
        min: 0,
        idleTimeoutMillis: 30000,
    },
};

sql.on('error', err => {
    console.log(err.message);
})

async function getDiagnosesAsync() {
    try{
        let pool = await sql.connect(config)
        let result1 = await pool.request().query('select * from VektisDiagnoses')
        console.log(result1)
        sql.close()
    } catch (err) {
        console.log(err.message)
        sql.close()

    }
}