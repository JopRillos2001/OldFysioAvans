const express = require('express')
const {graphqlHTTP} = require('express-graphql')
const {
    GraphQLSchema,
    GraphQLObjectType,
    GraphQLString,
    GraphQLList,
    GraphQLInt,
    GraphQLNonNull
} = require('graphql')

const games = [
    { id: 1, name: "Minecraft" },
    { id: 2, name: "Mario Bros" },
    { id: 3, name: "Five Nights at Freddy's" }
]

const characters = [
    { id: 1, name: "Steve", gameId: 1 },
    { id: 2, name: "Luigi", gameId: 2 },
    { id: 3, name: "Foxy", gameId: 3 },
    { id: 4, name: "Toad", gameId: 2 },
    { id: 5, name: "Yoshi", gameId: 2 },
    { id: 6, name: "Freddy", gameId: 3 },
    { id: 7, name: "Creeper", gameId: 1 },
    { id: 8, name: "Mario", gameId: 2 },
]

const CharacterType = new GraphQLObjectType({
    name: 'Character',
    description: "This represents a character inside a game",
    fields: () => ({
        id: { type: GraphQLNonNull(GraphQLInt) },
        name: {type: GraphQLNonNull(GraphQLString)},
        gameId: {type: GraphQLNonNull(GraphQLInt)},
        game: {
            type: GameType,
            resolve: (character) => {
                return games.find(game => game.id === character.gameId)
            }
        }
    })
})

const GameType = new GraphQLObjectType({
    name: 'Game',
    description: "This represents a game with characters",
    fields: () => ({
        id: { type: GraphQLNonNull(GraphQLInt) },
        name: {type: GraphQLNonNull(GraphQLString)},
        characters: {
            type: new GraphQLList(CharacterType),
            resolve: (game) => {
                return characters.filter(character => character.gameId === game.id)
            }
        }
    })
})

const RootQueryType = new GraphQLObjectType({
    name: 'Query',
    description: 'Root Query',
    fields: () => ({
        character: {
            type: CharacterType,
            description: "Single character",
            args: {
                id: { type: GraphQLInt }
            },
            resolve: (parent, args) => characters.find(character => character.id === args.id)
        },
        characters: {
            type: new GraphQLList(CharacterType),
            description: "List of characters",
            resolve: () => characters 
        },
        game: {
            type: GameType,
            description: "Single game",
            args: {
                id: { type: GraphQLInt }
            },
            resolve: (parent, args) => games.find(game => game.id === args.id)
        },
        games: {
            type: new GraphQLList(GameType),
            description: "List of games",
            resolve: () => games 
        }
    })
})

const RootMutationType = new GraphQLObjectType({
    name: 'Mutation',
    description: 'Root notations',
    fields: () => ({
        addCharacter: {
            type: CharacterType,
            description: "Add a character",
            args: {
                name: {type: GraphQLNonNull(GraphQLString)},
                gameId: {type: GraphQLNonNull(GraphQLInt)}
            },
            resolve: (parent, args) => {
                const character = {id: characters.length + 1, name: args.name, gameId: args.gameId}
                characters.push(character)
                return character
            }
        },
        addGame: {
            type: GameType,
            description: "Add a game",
            args: {
                name: {type: GraphQLNonNull(GraphQLString)}
            },
            resolve: (parent, args) => {
                const game = {id: games.length + 1, name: args.name}
                games.push(game)
                return game
            }
        }
    })
})

const schema = new GraphQLSchema({
    query: RootQueryType,
    mutation: RootMutationType
})

const app = express()

app.use('/graphql', graphqlHTTP ({
    schema: schema,
    graphiql: true
}))
app.listen(6504., () => console.log('Server Running'))